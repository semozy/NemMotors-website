(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_app_globals_162hn9o.css","static/chunks/node_modules_0cvqjih._.js","static/chunks/src_087qa8q._.js","static/chunks/src_0z090hj._.js","static/chunks/node_modules_next_1ht0kw-._.js","static/chunks/node_modules_@supabase_auth-js_dist_module_1vqrmkg._.js","static/chunks/node_modules_1ugbrnm._.js"],
    source: "entry"
});
