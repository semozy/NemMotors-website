(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_app_globals_162hn9o.css","static/chunks/node_modules_0cvqjih._.js","static/chunks/src_087qa8q._.js"],
    source: "entry"
});
